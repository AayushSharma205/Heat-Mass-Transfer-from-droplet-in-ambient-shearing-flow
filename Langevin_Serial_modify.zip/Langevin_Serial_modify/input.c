
void INPUT(int *OK, double *A, double *B, double* ALPHA1, double* ALPHA2, double* ALPHA3, int *N, int *n)
{
   double X; 
   char AA='Y';
   int i;

   *OK = false;
    if ((AA == 'Y') || (AA == 'y')) {
      *OK = false;
      while (!(*OK)) {
         if (*A >= *B) 
            printf("Left endpoint must be less than right endpoint\n");
         else *OK = true;
      }
     // printf("Input the three initial conditions, separated by blank.\n");
       FILE* in_file= fopen("InputData/Inputfile.txt", "r"); 
        if (in_file == NULL) {  
                printf("oops, file don't have data\n"); 
                exit(-1); 
             } 
        else{ 
           for(i=0; i<*n; i++)
	   fscanf(in_file, "%lf %lf %lf\n", &ALPHA1[i], &ALPHA2[i], &ALPHA3[i]);
             } 
	fclose(in_file);

      *OK = false;
      while(!(*OK)) {
         if (*N>0) printf("Done with input\n");
         if (*N <= 0) printf("Number must be a positive integer\n");
         else *OK = true;
      }
   }
   else {
      printf("The program will end so that the functions can be created.\n");
      *OK = false;
   }
}

