
 void memoryfree()
 {
free(bv);
free(W1);
free(W2);
free(W3);
free(dbv);
free(dW1);
free(dW2);
free(dW3);
 }
 
