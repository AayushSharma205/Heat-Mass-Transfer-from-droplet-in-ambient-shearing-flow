void calculation( )
{
int b=0,cont,k, fn_ct;
double temp=0.0;
double  f1,f2,f3,wt1,wt2,wt3;
double X11,X12,X13,X21,X22,X23,X31,X32,X33,X41,X42,X43;
double tden=(1.0/6.0);
int n_half=n*0.5;


FILE *OUP[1], *OUPdata[1];
OUTPUT(OUP);
//time_out(OUPtime);

/* STEP1 */ 
      Hnew=H*Pe;      
      T = A;
       
double fac=sqrt(2.0*H);

int see=1+(time(NULL)%100);
srand(see);

/* STEP 2 */
fprintf(*OUP,"%11.08f \t  %d \n",T, n_ct);


for(J=1; J<=N; J++) 	/* time loop*/										 	  
{
b=0;
for(i=0; i<n_ct; i++) 	/*random points (tracers) */
{
if(bv[i]==0){

f1=fac*randn();    f2=fac*randn();  	f3=fac*randn();
wt1=W1[i];         wt2=W2[i];           wt3=W3[i];   

        /* STEP 5 */
     X11 = Hnew *( F1( wt1, wt2, wt3) )+ f1;
     X12 = Hnew *( F2( wt1, wt2, wt3) )+ f2;
     X13 = Hnew * (F3( wt1, wt2, wt3) )+ f3;
         /* STEP 6 */
     X21 = Hnew * (F1( wt1 + X11*0.5, wt2 + X12*0.5, wt3 + X13*0.5) )+ f1;
     X22 = Hnew * (F2( wt1 + X11*0.5, wt2 + X12*0.5, wt3 + X13*0.5) )+ f2;
     X23 = Hnew * (F3( wt1 + X11*0.5, wt2 + X12*0.5, wt3 + X13*0.5) )+ f3;
         /* STEP 7  */
     X31 = Hnew * (F1( wt1 + X21*0.5, wt2 + X22*0.5, wt3 + X23*0.5) )+ f1;
     X32 = Hnew * (F2( wt1 + X21*0.5, wt2 + X22*0.5, wt3 + X23*0.5) )+ f2;
     X33 = Hnew * (F3( wt1 + X21*0.5, wt2 + X22*0.5, wt3 + X23*0.5) )+ f3;
         /* STEP 8  */
     X41= Hnew * (F1( wt1 + X31, wt2 + X32, wt3 + X33) )+ f1;
     X42= Hnew * (F2( wt1 + X31, wt2 + X32, wt3 + X33) )+ f2;
     X43= Hnew * (F3( wt1 + X31, wt2 + X32, wt3 + X33) )+ f3;     
	 /* STEP 9 */
     W1[i] = wt1 + tden*(X11 + 2.0*X21 + 2.0*X31 + X41);
     W2[i] = wt2 + tden*(X12 + 2.0*X22 + 2.0*X32 + X42);
     W3[i] = wt3 + tden*(X13 + 2.0*X23 + 2.0*X33 + X43);
     
       	/* STEP 9a */
    temp=W1[i]*W1[i] + W2[i]*W2[i] + W3[i]*W3[i]; /* Instead of r, we can use r^2 to check */

    if(temp>=1)
	 {
	b=b+1;
        bv[i]=1;
	 }
     else{
	bv[i-b]=0;  W1[i-b]=W1[i]; W2[i-b]=W2[i]; W3[i-b]=W3[i]; 
	dbv[i-b]=0;  dW1[i-b]=W1[i]; dW2[i-b]=W2[i]; dW3[i-b]=W3[i]; 
         }

	}
 } /*tracer loop end */
n_ct=n_ct-b;

if(n_ct<=n_half){
fn_ct=2.0*n_ct;  /* Number of tracers doubled at this instance */
for(k=n_ct;k<fn_ct;k++)
   { bv[k]=dbv[k-n_ct];   W1[k]=dW1[k-n_ct];  W2[k]=dW2[k-n_ct];  W3[k]=dW3[k-n_ct];  }

printf("\n old %d \t at %f \n", n_ct, T);
n_ct=fn_ct;
}

/*To find the concentration of tracers at each time */
/* STEP 10 */
T = A + J * H;
if(J%10==0){
fprintf(*OUP,"%11.08f \t  %d \n",T,n_ct);
}


if(J%10000000==0)
{ 
data_out(OUPdata);
fwrite(W1, sizeof(double), n_ct, *OUPdata);
fwrite(W2, sizeof(double), n_ct, *OUPdata);
fwrite(W3, sizeof(double), n_ct, *OUPdata); 
fclose(*OUPdata);
}



} /* time loop ends */

fclose(*OUP);
}
