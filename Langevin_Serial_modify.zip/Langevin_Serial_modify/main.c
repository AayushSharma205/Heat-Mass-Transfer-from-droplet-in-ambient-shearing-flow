/*    RUNGE-KUTTA FOR SYSTEMS OF 3 DIFFERENTIAL EQUATIONS n number of initial conditions */
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include <time.h>   	// for clock_t, clock(), CLOCKS_PER_SEC
#include <unistd.h> 	// for sleep()
#define true 1
#define false 0
//#define Pi 3.14159265358979323846264338327950
#define BILLION  1000000000.0
#include "parameters.c"
#include "memory.c"
#include "concentration.c"
#include "new_input.c"
#include "time_out.c"
#include "data_out.c"
#include "random_gen.c"
#include "output.c"
#include "memoryfree.c"
#include "fun1.c"
#include "fun2.c"
#include "fun3.c"
#include "sign.c"
#include "randn.c"
#include "calculation.c"

int main()
{
memory();
if( A==0){ random_gen();}
else {new_input();} 
calculation();
memoryfree();

return 0;

}

 

