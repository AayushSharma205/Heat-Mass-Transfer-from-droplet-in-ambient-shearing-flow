#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
    int i,k=2000000;
    double n=0;

    for(i = 0; i < k; i++) {                // get 3 random numbers
        n =(double) 0.5773*i / k ;      // in the range 0 ... 1
        printf("%f\n", n);                  // use correct format specifier for the var
    }
    return 0;
}
