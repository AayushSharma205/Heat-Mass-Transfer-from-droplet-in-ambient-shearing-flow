void random_gen()
{
int a=0,k=1,i,see,count=0;

double r,theta,phi,check1,check2;
double x1,x2,x3;
double b,c,d,e,f;

double rand_double(); /* 0.0 to 1.0, unif. dist. */
double rand_double2(double x, double y); /* c to d */
double uniform(double x, double y);/* a and b */

see=1+(time(NULL)%100);
srand(see);

/*Uniformly distributed tracer particles in cartesian*/
/*for(x1=-k1;x1<k1;x1=x1+stp1)
  {
  for(x2=-k1;x2<k1;x2=x2+stp1)
  {
      for(x3=-k1;x3<k1;x3=x3+stp1)
          {
         W1[a]=x1; 	  W2[a]=x2; 		W3[a]=x3;
         check1=pow(W1[a]*W1[a]+W2[a]*W2[a]+W3[a]*W3[a],0.5);
         if(check1<1)
            {	
            bv[a]=0;
            a=a+1;
            }
          }
  }
 }  */

/*Uniformly distributed tracer particles in side a sphere of radius unity */
for(a=0;a<n;a++)
{
phi=rand_double()*2*M_PI;
b=rand_double();
theta=acos(2*b-1);
//theta=acos(1-2*b);
r=pow(rand_double(),1./3.);

W1[a]=r*sin(theta)*cos(phi);
W2[a]=r*sin(theta)*sin(phi);
W3[a]=r*cos(theta);
bv[a]=0;
}
T=0;
concentration();
n=a;
}

/*Random number between 0 and 1 */
double rand_double() {   return rand()/(double)RAND_MAX;  }
/*Random number between x and y */
double rand_double2(double x, double y) { return (y - x)*rand_double() + x;}
double uniform(double x, double y){ return (((double)rand()+1)/((double)RAND_MAX+1))*(y-x) + x;} 

void rand_out(FILE **OUP)
      {
         int FLAG=2; 
         char NAME[150]; 
         char filename[30]="Inputfile"; 
         char Input[30]="InputData";
                  
         if (FLAG == 2) {
              	sprintf(NAME,"%s/%s.txt",Input,filename);
            	 *OUP= fopen(NAME,"w");
                        }
         else *OUP = stdout;
      }


