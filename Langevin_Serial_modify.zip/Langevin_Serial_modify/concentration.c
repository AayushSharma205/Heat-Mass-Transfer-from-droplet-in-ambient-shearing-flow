void concentration()
{
void concentration_out(FILE **);
FILE *OUP[1];
concentration_out(OUP);

double stp=0.05, stp1=0.0125, check1;
double k1=1.0,*rbin;
int *sumbin,temp,loop,a=0;
int i;
rbin = malloc((n+1)*sizeof(*rbin));
sumbin = malloc((n+1)*sizeof(*sumbin));

for(i=0;i<(k1/stp);i++)
{
sumbin[i]=0.0;
rbin[i]=i*stp+(0.5*stp);
}

for(a=0;a<n_ct;a++)
{
check1=sqrt(W1[a]*W1[a]+W2[a]*W2[a]+W3[a]*W3[a]);
temp=(int)(check1/stp);
sumbin[temp]+=1;
}

for(loop = 0; loop < (k1/stp); loop++){fprintf(*OUP," %d \t", sumbin[loop]);}
fclose(*OUP);

free(sumbin);
free(rbin);
}

void concentration_out(FILE **OUP)
{
   int FLAG=2; 
   char NAME[150]; 
   char filename[30]="Ct@T"; 
   char Input[30]="InputData";
   char at[30]="at";

  
   if (FLAG == 2) {
   	sprintf(NAME,"%s/%s%s%11.08f.txt",Input,filename,at,T);
   *OUP= fopen(NAME,"w");
     }
   else *OUP = stdout;
 }


