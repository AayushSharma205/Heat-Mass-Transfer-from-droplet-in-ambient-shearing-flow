double randn() 
{
    static double spare;
    static int hasSpare = false;
    double mean=0;
    double stdDev =1.0;//pow(H,0.5);

 if (hasSpare)
	{
        hasSpare = false;
        return spare * stdDev + mean;
    	} 
  else {
        double u, v, s;
        do {
            u = (rand() / ((double)RAND_MAX)) * 2.0 - 1.0;
            v = (rand() / ((double)RAND_MAX)) * 2.0 - 1.0;
            s = u * u + v * v;
            } while (s >= 1.0 || s == 0.0);
        s = sqrt(-2.0 * log(s) / s); /*Marsaglia polar method */
        spare = v * s;
        hasSpare = true;
        return mean + stdDev * u * s;
        }
}
