
double *W1,*W2,*W3;
int *bv;
double *dW1,*dW2,*dW3;
int *dbv;
double   D , E, test, test2;
int OK,St,i;
double T, Hnew; 
long int J;

/*C-D parameters */
int n=100000;  	 /*number of random points */
int n_ct=100000;  /*temp tracer at each time step */
double Pe=100.0;   /*Peclet number */


/*R-K parameters */
double A=0.0;	 /*initial time */
double B=10.0;	 /*final time */
long int N=1000000; 	 /* number of intervals between tmin and tmax */
double  H=0.00001;      /* time step */
