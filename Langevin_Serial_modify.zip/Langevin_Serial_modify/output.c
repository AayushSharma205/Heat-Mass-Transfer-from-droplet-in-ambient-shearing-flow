void OUTPUT(FILE **OUP)
{
   char NAME[150];
   int FLAG=2; 
   char filename[30]="Data"; 
   char Output[30]="OutputData";
   char at[30]="at"; 
   if (FLAG == 2) {
   sprintf(NAME,"%s/%s%.0f%s%d.txt",Output,filename,Pe,at,n);
   *OUP= fopen(NAME,"w");
   }
   else *OUP = stdout;
 }
