void new_input()
{
int y;
n_ct=97211;
char Tracers[60];
sprintf(Tracers,"InputData/data@Tat400with97211.bin");
 
FILE* in_file= fopen(Tracers,"rb"); 
	if (in_file == NULL) { printf("oops, file don't have data\n"); exit(-1); }
        else{
	  if(fread(W1, sizeof(double), n_ct, in_file)); 
           if(fread(W2, sizeof(double), n_ct, in_file)); 
           if(fread(W3, sizeof(double), n_ct, in_file)); 
           for(y=0; y<n_ct; y++) { 
				  bv[y]=0; 				 // printf("%11.35f %11.35f %11.35f \n", W1[y], W2[y], W3[y]);
				 }
           } 
	fclose(in_file);
        T=A;
        concentration();
}
