
int signum(double Si)
{
if (Si < 0) return -1;
if (Si>0) return 1;
return 0;
}

