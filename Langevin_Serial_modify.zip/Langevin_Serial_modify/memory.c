
void memory()
{
bv = malloc((n)*sizeof(*bv));
W1 = malloc((n)*sizeof(*W1));
W2 = malloc((n)*sizeof(*W2));
W3 = malloc((n)*sizeof(*W3));
dbv = malloc((n)*sizeof(*dbv));
dW1 = malloc((n)*sizeof(*dW1));
dW2 = malloc((n)*sizeof(*dW2));
dW3 = malloc((n)*sizeof(*dW3));
}
 
