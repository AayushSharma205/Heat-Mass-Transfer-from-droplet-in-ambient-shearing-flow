void data_out(FILE **OUP)
{
   int FLAG=2; 
   char NAME[150]; 
   char filename[30]="data@T"; 
   char Input[30]="InputData";
   char at[30]="at";
   char with[30]="with";

  
   if (FLAG == 2) {
   	sprintf(NAME,"%s/%s%s%4.02f%s%d.bin",Input,filename,at,T,with,n_ct);
        *OUP= fopen(NAME,"wb");
                 }
   else {
        *OUP = stdout;
        }
}

