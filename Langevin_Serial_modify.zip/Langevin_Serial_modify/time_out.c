void time_out(FILE **OUP)
{
   int FLAG=2; 
   char NAME[150]; 
   char filename[30]="Time"; 
   char Input[30]="InputData";
   char at[30]="at";

  
   if (FLAG == 2) {
   	sprintf(NAME,"%s/%s.txt",Input,filename);
   *OUP= fopen(NAME,"w");
     }
   else *OUP = stdout;
 }

