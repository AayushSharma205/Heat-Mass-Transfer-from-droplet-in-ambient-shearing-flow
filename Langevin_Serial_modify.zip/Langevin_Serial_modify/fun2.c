
double F2(double X1, double X2,  double X3 )
{

double Ca=0.0;
double lambda=1.0;

double f,f1,f2,X1_2,X2_2,X3_2,fac,fac1,temp;
X1_2=X1*X1;
X2_2=X2*X2;
X3_2=X3*X3;


f1=(1.0/2.0)*X1*(-5.0 + 5.0*X1_2 + X2_2 + 5.0*X3_2);

return  f1;
}


